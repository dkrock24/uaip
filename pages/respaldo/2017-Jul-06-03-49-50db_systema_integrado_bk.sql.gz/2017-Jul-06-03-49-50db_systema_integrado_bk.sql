SET FOREIGN_KEY_CHECKS=0; 
-- Dump de la Base de Datos
-- Fecha: Thursday 06 July 2017 - 15:49:50
--
-- Version: 1.1.1, del 18 de Marzo de 2005, insidephp@gmail.com
-- Soporte y Updaters: http://insidephp.sytes.net
--
-- Host: `localhost`    Database: `db_systema_integrado`
-- ------------------------------------------------------
-- Server version	10.0.25-MariaDB-1

--
-- Table structure for table `home_carrusel`
--

