SET FOREIGN_KEY_CHECKS=0; 
-- Dump de la Base de Datos
-- Fecha: Tuesday 18 July 2017 - 00:19:17
--
-- Version: 1.1.1, del 18 de Marzo de 2005, insidephp@gmail.com
-- Soporte y Updaters: http://insidephp.sytes.net
--
-- Host: `localhost`    Database: `db_systema_integrado`
-- ------------------------------------------------------
-- Server version	10.0.25-MariaDB-1

--
-- Table structure for table `home_carrusel`
--

